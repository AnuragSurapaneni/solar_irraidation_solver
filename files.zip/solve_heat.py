"""
Step 2 of 2: Read the mesh + material markers + precomputed view-factor/flux
data written by compute_view_factors.py and solve the transient shell heat
equation, with per-material thermal properties.

Materials are matched by NAME between the two scripts (not by index/order),
via MATERIAL_PROPERTIES below and the material_names array saved in
view_factors.npz. All materials live on one continuous mesh sharing a
single CG1 temperature field, so contact between materials is automatically
zero-resistance (continuous temperature, no interface condition needed) --
this relies on compute_view_factors.py having welded coincident vertices
at part interfaces.

Can be run with a different number of MPI ranks than the view-factor step --
it only depends on files on disk (mesh_surface.xdmf, material_markers.xdmf,
view_factors.npz).

Run with:
    mpirun -n N python solve_heat.py
"""

from dolfin import *
import numpy as np
from scipy.spatial import cKDTree
from mpi4py import MPI

# ------------------------------------------------------------------
# USER INPUTS
# ------------------------------------------------------------------

XDMF_MESH_PATH = "mesh_surface.xdmf"
MATERIAL_XDMF_PATH = "material_markers.xdmf"
VIEW_FACTOR_IN = "view_factors.npz"

START_OFFSET_SECONDS = 0.0

# Per-material thermal properties, keyed by the same "name" used in
# MATERIALS in compute_view_factors.py.
MATERIAL_PROPERTIES = {
    "tube_body": dict(RHO=800.0,  CP=400.0, K_COND=13.0,  THICKNESS=0.002, H_FRONT=5.0,  H_BACK=5.0,  EMISSIVITY=0.0),
    # "end_cap":  dict(RHO=2700.0, CP=900.0, K_COND=205.0, THICKNESS=0.003, H_FRONT=8.0,  H_BACK=8.0,  EMISSIVITY=0.1),
    # "bracket":  dict(RHO=7850.0, CP=490.0, K_COND=50.0,  THICKNESS=0.004, H_FRONT=10.0, H_BACK=10.0, EMISSIVITY=0.2),
}

SIGMA_SB = 5.670374419e-8
T_AMB = 293.15

dt = 60.0

comm = MPI.COMM_WORLD
rank = comm.Get_rank()

# ------------------------------------------------------------------
# Load precomputed view-factor / flux / material-name data. Every rank
# reads the same file directly off disk, so no MPI broadcast is needed.
# ------------------------------------------------------------------
data = np.load(VIEW_FACTOR_IN)
face_centers = data["face_centers"]
solar_t = data["solar_t"]
flux_per_solar_step = data["flux_per_solar_step"]
material_names = [str(n) for n in data["material_names"]]

missing = [n for n in material_names if n not in MATERIAL_PROPERTIES]
if missing:
    raise ValueError(
        f"MATERIAL_PROPERTIES is missing entries for: {missing}. "
        f"Every material saved in {VIEW_FACTOR_IN} needs a matching name here."
    )

SIM_DURATION_SECONDS = solar_t[-1] - START_OFFSET_SECONDS
num_steps = int(np.ceil(SIM_DURATION_SECONDS / dt))

if rank == 0:
    print(f"Simulating {SIM_DURATION_SECONDS/3600:.2f} hours "
          f"({num_steps} steps of dt={dt}s)")
    print(f"Materials: {material_names}")

mesh = Mesh()
with XDMFFile(comm, XDMF_MESH_PATH) as infile:
    infile.read(mesh)

# Read per-cell material id (written as cell_data by compute_view_factors.py)
mvc = MeshValueCollection("size_t", mesh, mesh.topology().dim())
with XDMFFile(comm, MATERIAL_XDMF_PATH) as infile:
    infile.read(mvc, "material_id")
material_mf = MeshFunction("size_t", mesh, mvc)

V_flux = FunctionSpace(mesh, "CG", 1)
V = FunctionSpace(mesh, "P", 1)
tree = cKDTree(face_centers)

# tabulate_dof_coordinates() returns owned dofs followed by ghost dofs
# (needed for cross-partition assembly), but Function.vector().set_local()
# only accepts values for the OWNED dofs. Slice to owned-only to avoid
# writing out of bounds, which otherwise corrupts the PETSc vector and
# shows up later as an unrelated-looking VecAssemblyBegin MPI error.
n_owned = V_flux.dofmap().ownership_range()[1] - V_flux.dofmap().ownership_range()[0]
dof_coords = V_flux.tabulate_dof_coordinates()[:n_owned]
_, dof_to_face_idx = tree.query(dof_coords)
flux = Function(V_flux, name="SolarFlux")


def flux_at_time(t_abs):
    if t_abs <= solar_t[0]:
        idx = 0
    else:
        idx = np.searchsorted(solar_t, t_abs, side="right") - 1
        idx = min(idx, len(solar_t) - 1)
    return flux_per_solar_step[idx][dof_to_face_idx]


# ------------------------------------------------------------------
# Build per-cell (DG0) material property fields from the MeshFunction.
# Each local cell's dof in a DG0 space corresponds 1:1, in the same order,
# to that cell's index -- so material_mf.array() (local cell material ids)
# can be used directly to build the per-cell property array.
# ------------------------------------------------------------------
Vdg = FunctionSpace(mesh, "DG", 0)
local_material_ids = material_mf.array()
local_material_names = [material_names[mid] for mid in local_material_ids]


def make_dg_field(prop_key):
    values = np.array(
        [MATERIAL_PROPERTIES[name][prop_key] for name in local_material_names],
        dtype=np.float64,
    )
    f = Function(Vdg)
    f.vector().set_local(values)
    f.vector().apply("insert")
    return f


rho = make_dg_field("RHO")
cp = make_dg_field("CP")
k = make_dg_field("K_COND")
thickness = make_dg_field("THICKNESS")
h_front = make_dg_field("H_FRONT")
h_back = make_dg_field("H_BACK")
emissivity = make_dg_field("EMISSIVITY")

T_amb = Constant(T_AMB)
sigma_sb = Constant(SIGMA_SB)

u = Function(V, name="Temperature")
u_n = Function(V)
v = TestFunction(V)

# --- initial condition ---
u_n.interpolate(Constant(T_AMB))
u.assign(u_n)

# --- lumped mass matrix (per-area heat capacity, spatially varying) ---
M = assemble(rho * cp * thickness * u * v * dx)
ones = Function(V)
ones.vector()[:] = 1.0
M_diag = (M * ones.vector()).get_local()

# --- output ---
xdmf = XDMFFile(comm, "shell_heat.xdmf")
xdmf.parameters["flush_output"] = True
xdmf.parameters["functions_share_mesh"] = True

# Write the material map once for reference/visualization alongside results
material_out = Function(Vdg, name="MaterialID")
material_out.vector().set_local(local_material_ids.astype(np.float64))
material_out.vector().apply("insert")
xdmf.write(material_out, 0.0)

# --- time loop ---
t = 0.0
save_every = 30 * 60  # (Save every 30 mins)
next_save = save_every
for n in range(num_steps):
    t += dt
    t_abs = START_OFFSET_SECONDS + t

    flux.vector().set_local(flux_at_time(t_abs))
    flux.vector().apply("insert")

    F = (
        -k * thickness * dot(grad(u_n), grad(v)) * dx
        + flux * v * dx
        - h_front * (u_n - T_amb) * v * dx
        - h_back * (u_n - T_amb) * v * dx
        - emissivity * sigma_sb * (u_n**4 - T_amb**4) * v * dx
    )
    b = assemble(F).get_local()

    u_vec = u.vector().get_local()
    u_n_vec = u_n.vector().get_local()
    u_vec[:] = u_n_vec + dt * (b / M_diag)

    u.vector().set_local(u_vec)
    u.vector().apply("insert")
    u_n.assign(u)

    if t >= next_save:
        xdmf.write(u, t)
        xdmf.write(flux, t)
        next_save += save_every

    # min()/max() on a PETSc vector are collective calls: every rank must
    # call them, even though only rank 0 prints the result.
    flux_min, flux_max = flux.vector().min(), flux.vector().max()
    u_min, u_max = u.vector().min(), u.vector().max()
    if rank == 0:
        print(f"[solve] step {n}, t={t:.3f}s (t_abs={t_abs:.1f}s), "
              f"flux range [{flux_min:.1f}, {flux_max:.1f}] W/m^2, "
              f"T range [{u_min:.2f}, {u_max:.2f}] K")

if rank == 0:
    print("Done. Wrote shell_heat.xdmf (temperature + flux + material map, all materials combined).")
